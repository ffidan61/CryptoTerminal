# CryptoTerminal

Track your crypto currency porfolio in your terminal using the [CryptoCompare](https://min-api.cryptocompare.com) API.

